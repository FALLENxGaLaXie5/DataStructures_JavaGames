/**
 * Dealer class for the game of Even Or Odd
 *
 * @author YOUR NAME
 * @version: 10/11/14
 */
public class Dealer
{
    // Declare instance variables here

    /**
     * Constructor  creates two Die objects
     */
    public Dealer()
    {
        System.out.println("In Dealer constructor - IMPLEMENT ME");
    }

    /**
     * The shakeDiceCup method rolls both dice
     */
    public void shakeDiceCup()
    {
        System.out.println("In shakeDiceCup method - IMPLEMENT ME");
    }

    /**
     * The calculateEvenOrOdd method returns the result of the dice roll
     *
     * @return EVEN if the sum of two dice roll is even, or ODD otherwise
     */
    public String calculateEvenOrOdd()
    {
        System.out.println("In calculateEvenOrOdd method - IMPLEMENT ME");

        return "???";   // THIS IS A STUB
    }

    /**
     * @return String representation of the dealer's roll
     */
    public String toString()
    {
        return "???";   // THIS IS A STUB
    }
}