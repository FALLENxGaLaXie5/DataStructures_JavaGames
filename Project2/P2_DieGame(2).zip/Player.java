import java.util.Random;

/**
 * Player class for the game of Odd or Even
 *
 * @author: YOUR NAME
 * @version: 10/11/14
 */
public class Player
{
    // Declare instance variables here

    /**
     * Constructor  sets the name to the given playersName,
     *                   guess is set to empty string, and points to 0
     *
     * @param playerName The player's name
     */
    public Player(String playerName)
    {
        System.out.println("In Player constructor - IMPLEMENT ME");
    }

    /**
     * The makeGuess method causes the player to guess either EVEN or ODD
     * Creates a random object and utilizes nextBoolean method
     */
    public void makeGuess()
    {
        System.out.println("In makeGuess method - IMPLEMENT ME");
    }

    /**
     * The addPoint method adds one point to the player's current balance
     */
    public void addPoint()
    {
        System.out.println("In addPoint method - IMPLEMENT ME");
    }

    /**
     * Accessor method
     *
     * @return the player's name field
     */
    public String getName()
    {
        return ""; // THIS IS A STUB
    }

    /**
     * Accessor method
     *
     * @return the value of the guess field
     */
    public String getGuess()
    {
        return "";  // THIS IS A STUB
    }

    /**
     * Accessor method
     *
     * @return the value of the points field
     */
    public int getPoints()
    {
        return 0; // THIS IS A STUB
    }

    /**
     * @return the String representation of the content of the player's object:
     *                    only players name and the numbers of points are given
     */
    public String toString()
    {
        return "???";    // THIS IS A STUB
    }
}