/**
 * Created by ania on 3/3/15.
 * Joshua Steward
 */

import java.util.Queue;
public class CircularArrayQueue<T> implements QueueInterface<T>
{
    private T[] queue; // Circular array of queue entries and one unused location
    private int frontIndex; // Index of front entry
    private int backIndex;  // Index of back entry
    private boolean initialized = false;
    private static final int DEFAULT_CAPACITY = 3;
    private static final int MAX_CAPACITY = 10000;

    public CircularArrayQueue()
    {
        this(DEFAULT_CAPACITY);
    } // end default constructor

    public CircularArrayQueue(int initialCapacity)
    {
        checkCapacity(initialCapacity);

        // The cast is safe because the new array contains null entries
        @SuppressWarnings("unchecked")
        T[] tempQueue = (T[]) new Object[initialCapacity + 1];
        this.queue = tempQueue;
        this.frontIndex = 0;
        this.backIndex = initialCapacity;
        this.initialized = true;
    } // end constructor

    public void enqueue(T newEntry)
    {
        this.queue[backIndex] = newEntry;
        System.out.println("enqueue method - IMPLEMENT ME");
    } // end enqueue

    public T getFront()
    {
        System.out.println("getFront method - IMPLEMENT ME");
        return null;
    } // end getFront

    public T dequeue()
    {
        System.out.println("dequeue method - IMPLEMENT ME");
        return null;
    } // end dequeue

    public boolean isEmpty()
    {
        System.out.println("isEmpty method - IMPLEMENT ME");
        return true;  // THIS IS A STUB
    } // end isEmpty

    public void clear()
    {

        // null out only the used slots
        System.out.println("clear method - IMPLEMENT ME");


    } // end clear


    // Throws an exception if this object is not initialized.
    private void checkInitialization()
    {
        if (!initialized)
            throw new SecurityException("CircularArrayQueue object is not initialized properly.");
    } // end checkInitialization

    // Throws an exception if the client requests a capacity that is too large.
    private void checkCapacity(int capacity)
    {
        if (capacity > MAX_CAPACITY)
            throw new IllegalStateException("Attempt to create a queue " +
                    "whose capacity exceeds " +
                    "allowed maximum.");
    } // end checkCapacity

    // Doubles the size of the array queue if it is full.
    // Precondition: checkInitialization has been called.
    private void ensureCapacity()
    {

        System.out.println("Doubling Array Size - IMPLEMENT ME");


    } // end ensureCapacity
}
