/**
 * Created by joshua.steward095 on 1/22/2015.
 */
public class CountHeadsGame
{
    public static void main(String[] args)
    {

    }
}
