/**
 * Created by joshua.steward095 on 1/22/2015.
 */
import java.util.Random;
public abstract class Money
{
    private int denomination;
    private boolean heads;

    public Money(int numOfDenominations)
    {
        Random random = new Random();
        this.denomination = random.nextInt(numOfDenominations);
        this.heads = false;
    }

    public int getDenomination()
    {
        return this.denomination;
    }

    public abstract double getValue();

    public void toss()
    {
        this.heads = new Random().nextBoolean();
    }

    public boolean isHeads()
    {
        if (this.heads)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public abstract String toString();
}
