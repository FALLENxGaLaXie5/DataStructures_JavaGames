/**
 * Created by Joshua Steward on 1/22/2015.
 */
import java.util.Random;
public class PiggyBank
{
    private BagInterface<Money> piggyBank;
    private int capacity;

    public PiggyBank(int newCapacity, int numOfMoniesToBeAdded)
    {
        this.capacity = newCapacity;
        this.piggyBank = new ResizableArrayBag<Money>(this.capacity);
        Random random = new Random();

        for (int i = 0; i < numOfMoniesToBeAdded; i++)
        {
            if (random.nextBoolean())
            {
                add(new Coin());
            }
            else
            {
                add(new Bill());
            }
        }
    }



    public void add(Money moniez) throws PiggyBankFullException
    {
        this.piggyBank.add(moniez);
    }

    public Money remove()
    {
        Money moniez = this.piggyBank.remove();
        return moniez;
    }

    public boolean isEmpty()
    {
        boolean answer = this.piggyBank.isEmpty();
        return answer;
    }

    public boolean isFull()
    {
        boolean answer = this.piggyBank.isFull();
        return answer;
    }

    public int getCapacity()
    {
        return this.capacity;
    }

    public int emptyAndCountHeads()
    {
        return 0;
    }

    public String toString()
    {
        return "";
    }
}
