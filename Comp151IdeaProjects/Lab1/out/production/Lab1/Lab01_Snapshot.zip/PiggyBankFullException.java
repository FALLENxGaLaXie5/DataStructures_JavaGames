/**
 * Created by Joshua Steward on 1/22/2015.
 */
public class PiggyBankFullException
{
}
