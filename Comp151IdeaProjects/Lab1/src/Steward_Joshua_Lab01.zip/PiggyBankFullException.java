/**
 * Created by Joshua Steward on 1/22/2015.
 */
public class PiggyBankFullException extends Exception
{
    public PiggyBankFullException( String exceptionString)
    {
        System.out.println(exceptionString);
    }
}
