/**
 * Created by Joshua Steward on 11/9/2014.
 */
import java.util.ArrayList;
public class SumOfList
{
    public SumOfList()
    {

    }
    public int Sum(ArrayList<Integer> objects)
    {
        int sum = 0;
        for (Integer number : objects)
        {
            sum+= number;
        }
        return sum;
    }
}
