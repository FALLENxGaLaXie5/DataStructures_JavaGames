/**
 * Created by Joshua Steward on 11/9/2014.
 */
import java.util.ArrayList;
public class SumOfListClient
{
    public static void main( String [] args )
    {
        ArrayList<Integer> ham = new ArrayList<Integer>();
        ham.add(1);
        ham.add(3);
        ham.add(5);
        ham.add(1);
        ham.add(2);
        ham.add(0);
        ham.add(2);
        ham.trimToSize();

        SumOfList newSum = new SumOfList();
        System.out.println("The sum of this list is " + newSum.Sum(ham));
    }
}
