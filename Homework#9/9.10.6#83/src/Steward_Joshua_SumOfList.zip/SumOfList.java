/**
 * Created by Joshua Steward on 11/9/2014 */
import java.util.ArrayList;

public class SumOfList
{
    private ArrayList<Integer> integersList;

    public SumOfList()
    {
        integersList = new ArrayList<Integer>();
        integersList.add(1);
        integersList.add(3);
        integersList.add(2);
        integersList.add(7);
        integersList.add(3);
        integersList.add(2);
        integersList.trimToSize();
    }

    public String toString()
    {
        String result = "";
        for (Integer number : integersList)
        {
            result += number.toString() + "\n";
        }
        return result;
    }

    public int Sum()
    {
        int sum = 0;
        for (Integer number : integersList)
        {
            sum+= number;
        }
        return sum;
    }
}
