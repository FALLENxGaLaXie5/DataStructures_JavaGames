/**
 * Created by Joshua Steward on 11/9/2014.
 */

public class SumOfListClient
{
    public static void main( String [] args )
    {
        SumOfList newSum = new SumOfList();
        System.out.println("The sum of this list is " + newSum.Sum());
    }
}
