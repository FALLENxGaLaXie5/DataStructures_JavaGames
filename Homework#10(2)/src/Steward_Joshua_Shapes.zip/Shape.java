/**
 * Created by Joshua Steward on 11/19/2014.
 */
public abstract class Shape
{
    public abstract double calculatePerimeter();
    public abstract double calculateArea();
}
