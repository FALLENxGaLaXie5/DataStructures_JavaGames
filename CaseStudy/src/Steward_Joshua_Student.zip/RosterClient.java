import java.util.*;

/**
 * Created by Joshua on 11/19/2014.
 */
public class RosterClient
{
    public static void main( String [] args)
    {
        ArrayList<Student> roster1 = new ArrayList<Student>();
        int studentNumber = 40;
        int grade = 0;
        Random ran = new Random();


    }
}
